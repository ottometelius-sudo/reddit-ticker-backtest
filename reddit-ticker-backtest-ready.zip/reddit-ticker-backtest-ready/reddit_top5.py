import os
import re
import time
import math
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Set, Tuple, Optional

import pandas as pd
import praw
import yfinance as yf
from tqdm import tqdm

"""
reddit_top5.py

Read-only script:
- Reads public subreddit submissions (no posting/commenting/voting)
- Extracts tickers
- Applies "Large & Liquid" filters
- Measures +50% hits within 12 months
- Ranks subreddits by Wilson lower bound (95%) for reliability

Outputs:
- data/top50_wilson_lb.csv
- data/all_picks.csv
"""

# -----------------------------
# CONFIG (edit safely)
# -----------------------------
SUBREDDITS = [
    # US / global
    "stocks",
    "StockMarket",
    "SecurityAnalysis",
    "ValueInvesting",
    "investing",
    "Trading",
    "Daytrading",
    "RealDayTrading",
    "options",
    "thetagang",
    "wallstreetbets",
    "smallstreetbets",
    # Sweden
    "Aktiemarknaden",
    "ISKbets",
]

LOOKBACK_DAYS = 365

# Ranking robustness
MIN_PICKS_PER_SUB = 100

# Scan depth per subreddit (Reddit listing APIs have practical limits)
MAX_SUBMISSIONS_PER_SUB = 1500

# Gentle throttling
SLEEP_SECONDS_PER_SUBMISSION = 0.02

# Large & Liquid only
MIN_MARKET_CAP = 1_000_000_000        # 1B USD
MIN_AVG_DOLLAR_VOL_20D = 10_000_000    # 10M USD/day

SWEDISH_SUFFIXES = [".ST"]

STOPWORDS = {
    "CEO","CFO","DD","YOLO","ATH","IMO","USA","SEC","ETF","FOMO","TLDR","GDP","FED","PMI",
    "AI","IPO","USD","EUR","SEK","EU","UK","ELI5","EDIT","OP","TIL","FYI",
    "THIS","THAT","WITH","FROM","WILL","HAVE","YOUR","JUST","WHAT","WHEN","THEN",
}

# Ticker patterns:
DOLLAR_TICKER_RE = re.compile(r"\$([A-Z]{1,6}(?:\.[A-Z]{1,4})?)\b")
PLAIN_TICKER_RE  = re.compile(r"\b([A-Z]{2,5}(?:\.[A-Z]{1,4})?)\b")

# -----------------------------
# CACHES
# -----------------------------
PRICE_TICKER_CACHE: Dict[str, pd.Series] = {}
TICKER_META_CACHE: Dict[str, dict] = {}
TICKER_HIST_CACHE: Dict[tuple, pd.DataFrame] = {}


@dataclass
class PickResult:
    subreddit: str
    post_id: str
    created_utc: datetime
    ticker: str              # used ticker (e.g. EVO.ST)
    entry_date: datetime
    entry_price: float
    eval_date: datetime
    eval_price: float
    ret: float
    hit_50: bool


def wilson_lower_bound(k: int, n: int, z: float = 1.96) -> float:
    """Conservative lower bound for a binomial proportion (95% by default)."""
    if n <= 0:
        return 0.0
    p = k / n
    denom = 1.0 + (z*z)/n
    centre = p + (z*z)/(2*n)
    margin = z * math.sqrt((p*(1-p) + (z*z)/(4*n)) / n)
    return (centre - margin) / denom


def is_probable_ticker(tok: str) -> bool:
    if tok in STOPWORDS:
        return False
    if len(tok) == 1:
        return False
    return True


def extract_tickers(text: str) -> Set[str]:
    if not text:
        return set()
    out: Set[str] = set()

    # $TICKER (preferred)
    for m in DOLLAR_TICKER_RE.finditer(text):
        out.add(m.group(1))

    # Plain tickers (more false positives)
    for m in PLAIN_TICKER_RE.finditer(text):
        tok = m.group(1)
        if is_probable_ticker(tok):
            out.add(tok)

    return out


def yf_download_close(ticker: str, start: datetime, end: datetime) -> Optional[pd.Series]:
    """Download daily close series (prefers Adj Close if available)."""
    try:
        df = yf.download(
            ticker,
            start=start.date().isoformat(),
            end=end.date().isoformat(),
            auto_adjust=False,
            progress=False,
            threads=True,
        )
        if df is None or df.empty:
            return None

        col = "Adj Close" if "Adj Close" in df.columns else "Close"
        s = df[col].dropna()
        if s.empty:
            return None

        s.index = pd.to_datetime(s.index).tz_localize(None)
        return s
    except Exception:
        return None


def get_price_series(ticker: str, start: datetime, end: datetime) -> Optional[pd.Series]:
    key = f"{ticker}|{start.date()}|{end.date()}"
    if key in PRICE_TICKER_CACHE:
        return PRICE_TICKER_CACHE[key]
    s = yf_download_close(ticker, start, end)
    if s is not None:
        PRICE_TICKER_CACHE[key] = s
    return s


def try_price_lookup(ticker: str, start: datetime, end: datetime) -> Tuple[Optional[pd.Series], Optional[str]]:
    """Try raw ticker first, then Swedish suffix variants."""
    s = get_price_series(ticker, start, end)
    if s is not None:
        return s, ticker

    if "." not in ticker:
        for suf in SWEDISH_SUFFIXES:
            t2 = ticker + suf
            s2 = get_price_series(t2, start, end)
            if s2 is not None:
                return s2, t2

    return None, None


def next_trading_price(series: pd.Series, dt_utc: datetime) -> Optional[Tuple[datetime, float]]:
    """First available daily price on or after dt_utc.date()."""
    target = pd.Timestamp(dt_utc.date())
    future = series.index[series.index >= target]
    if len(future) == 0:
        return None
    d = future[0].to_pydatetime().replace(tzinfo=timezone.utc)
    return d, float(series.loc[future[0]])


def get_ticker_meta(used_ticker: str) -> dict:
    if used_ticker in TICKER_META_CACHE:
        return TICKER_META_CACHE[used_ticker]
    meta = {"marketCap": None}
    try:
        info = yf.Ticker(used_ticker).get_info()
        meta["marketCap"] = info.get("marketCap", None)
    except Exception:
        pass
    TICKER_META_CACHE[used_ticker] = meta
    return meta


def get_history_df(used_ticker: str, start: datetime, end: datetime) -> Optional[pd.DataFrame]:
    key = (used_ticker, start.date().isoformat(), end.date().isoformat())
    if key in TICKER_HIST_CACHE:
        return TICKER_HIST_CACHE[key]
    try:
        df = yf.Ticker(used_ticker).history(
            start=start.date().isoformat(),
            end=end.date().isoformat(),
            auto_adjust=False,
        )
        if df is None or df.empty:
            return None
        TICKER_HIST_CACHE[key] = df
        return df
    except Exception:
        return None


def passes_large_liquid_only(used_ticker: str, created: datetime) -> bool:
    """Large (>= $1B cap) and Liquid (>= $10M/day avg $ volume over ~20 trading days)."""
    mc = get_ticker_meta(used_ticker).get("marketCap", None)
    if mc is None or mc < MIN_MARKET_CAP:
        return False

    hist_start = created - timedelta(days=3)
    hist_end = created + timedelta(days=40)

    df = get_history_df(used_ticker, hist_start, hist_end)
    if df is None or df.empty or "Close" not in df.columns or "Volume" not in df.columns:
        return False

    df = df.dropna(subset=["Close", "Volume"]).copy()
    if df.empty:
        return False

    df.index = pd.to_datetime(df.index).tz_localize(None)
    cutoff = pd.Timestamp(created.date())
    df = df[df.index >= cutoff].head(25)

    if len(df) < 10:
        return False

    avg_dollar_vol = float((df["Close"] * df["Volume"]).mean())
    return avg_dollar_vol >= MIN_AVG_DOLLAR_VOL_20D


def score_subreddits(
    reddit: praw.Reddit,
    subreddits: List[str],
    start_utc: datetime,
    now_utc: datetime,
    max_submissions: int,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    results: List[PickResult] = []
    price_window_start = start_utc - timedelta(days=5)
    price_window_end = now_utc + timedelta(days=5)

    for sub in subreddits:
        sr = reddit.subreddit(sub)

        for submission in tqdm(sr.new(limit=max_submissions), desc=f"Scanning r/{sub}"):
            created = datetime.fromtimestamp(submission.created_utc, tz=timezone.utc)
            if created < start_utc:
                break

            text = f"{submission.title}\n{submission.selftext or ''}"
            tickers = extract_tickers(text)
            if not tickers:
                time.sleep(SLEEP_SECONDS_PER_SUBMISSION)
                continue

            for t in tickers:
                series, used_ticker = try_price_lookup(t, price_window_start, price_window_end)
                if series is None or used_ticker is None:
                    continue

                if not passes_large_liquid_only(used_ticker, created):
                    continue

                entry = next_trading_price(series, created)
                if entry is None:
                    continue
                entry_date, entry_px = entry

                eval_dt = min(created + timedelta(days=LOOKBACK_DAYS), now_utc)
                evalp = next_trading_price(series, eval_dt)
                if evalp is None:
                    continue
                eval_date, eval_px = evalp

                ret = (eval_px / entry_px) - 1.0
                results.append(PickResult(
                    subreddit=sub,
                    post_id=submission.id,
                    created_utc=created,
                    ticker=used_ticker,
                    entry_date=entry_date,
                    entry_price=entry_px,
                    eval_date=eval_date,
                    eval_price=eval_px,
                    ret=ret,
                    hit_50=(ret >= 0.50),
                ))

            time.sleep(SLEEP_SECONDS_PER_SUBMISSION)

    if not results:
        return pd.DataFrame(), pd.DataFrame()

    df = pd.DataFrame([r.__dict__ for r in results])

    agg = (df.groupby("subreddit")
           .agg(
               picks=("ticker", "count"),
               unique_tickers=("ticker", "nunique"),
               hits_50=("hit_50", "sum"),
               hit_rate=("hit_50", "mean"),
               median_return=("ret", "median"),
               p90_return=("ret", lambda x: x.quantile(0.90)),
           )
           .reset_index())

    agg["wilson_lb_95"] = agg.apply(
        lambda r: wilson_lower_bound(int(r["hits_50"]), int(r["picks"]), 1.96),
        axis=1
    )

    agg = agg[agg["picks"] >= MIN_PICKS_PER_SUB].copy()
    agg = agg.sort_values(
        ["wilson_lb_95", "hit_rate", "hits_50", "picks"],
        ascending=[False, False, False, False]
    )

    return agg, df


def make_reddit_client() -> praw.Reddit:
    cid = os.environ.get("REDDIT_CLIENT_ID", "").strip()
    secret = os.environ.get("REDDIT_CLIENT_SECRET", "").strip()
    ua = os.environ.get("REDDIT_USER_AGENT", "").strip()

    if not cid or not secret or not ua:
        raise SystemExit(
            "Missing Reddit credentials. Set env vars:\n"
            "  REDDIT_CLIENT_ID\n"
            "  REDDIT_CLIENT_SECRET\n"
            "  REDDIT_USER_AGENT\n"
        )

    return praw.Reddit(
        client_id=cid,
        client_secret=secret,
        user_agent=ua,
    )


def main() -> None:
    now_utc = datetime.now(timezone.utc)
    start_utc = now_utc - timedelta(days=LOOKBACK_DAYS)

    reddit = make_reddit_client()

    agg, raw = score_subreddits(
        reddit=reddit,
        subreddits=SUBREDDITS,
        start_utc=start_utc,
        now_utc=now_utc,
        max_submissions=MAX_SUBMISSIONS_PER_SUB,
    )

    os.makedirs("data", exist_ok=True)

    if agg.empty:
        print("No results. Try increasing MAX_SUBMISSIONS_PER_SUB or adjusting ticker extraction rules.")
        return

    print("\n=== TOP 5 (Most reliable) Wilson LB 95% | Large & Liquid only | +50% within 12 months ===")
    print(agg.head(5).to_string(index=False))

    agg.head(50).to_csv("data/top50_wilson_lb.csv", index=False)
    raw.to_csv("data/all_picks.csv", index=False)
    print("\nSaved: data/top50_wilson_lb.csv, data/all_picks.csv")


if __name__ == "__main__":
    main()
