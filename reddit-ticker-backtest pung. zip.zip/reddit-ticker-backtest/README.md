# reddit-ticker-backtest

Read-only research script that uses Reddit’s API (via PRAW) to collect **public subreddit submissions** and perform **offline analytics** on stock tickers mentioned in posts.

## What it does (high level)
- Reads public submissions from a predefined list of subreddits (last 12 months).
- Extracts stock tickers mentioned in post title/body (e.g. `$TSLA` or `TSLA`).
- Applies **Large & Liquid** filters to reduce microcap/illiquidity bias:
  - Market cap >= **$1B**
  - Avg **$ volume** over ~20 trading days after post date >= **$10M/day**
- Backtests: a “hit” is a ticker that reaches **+50%** within 12 months from the post date (entry = next trading day).
- Aggregates results per subreddit and ranks by **Wilson score lower bound (95%)** for reliability.

## What it does NOT do
- No posting, commenting, voting, messaging, or moderation actions.
- No scraping of private communities, DMs, or private user data.
- No user profiling. Output is subreddit-level analytics.

## Data stored
The script saves local CSV outputs only:
- `data/all_picks.csv` — per (post, ticker) measurement:
  - subreddit, post_id, created_utc, ticker, entry_date/price, eval_date/price, return, hit_50
- `data/top50_wilson_lb.csv` — subreddit-level ranking table

## Requirements
- Python 3.10+ recommended
- A Reddit “script” app (client_id, client_secret)
- Internet access (for Reddit API + Yahoo Finance via yfinance)

## Setup
### 1) Create Reddit API credentials
Create a **script** app at:
https://www.reddit.com/prefs/apps

You will get:
- `client_id`
- `client_secret`

### 2) Install dependencies
```bash
python -m venv venv
source venv/bin/activate  # mac/linux
# venv\Scripts\activate  # windows
pip install -r requirements.txt
```

### 3) Set environment variables (recommended)
```bash
export REDDIT_CLIENT_ID="..."
export REDDIT_CLIENT_SECRET="..."
export REDDIT_USER_AGENT="script:reddit-ticker-backtest:1.0 (by u_yourusername)"
```

Windows PowerShell:
```powershell
setx REDDIT_CLIENT_ID "..."
setx REDDIT_CLIENT_SECRET "..."
setx REDDIT_USER_AGENT "script:reddit-ticker-backtest:1.0 (by u_yourusername)"
```

### 4) Run
```bash
python reddit_top5.py
```

Optional: edit `SUBREDDITS` and limits at the top of `reddit_top5.py`.

## Notes / limitations
- Reddit listing APIs have practical pagination limits; scanning depth depends on `MAX_SUBMISSIONS_PER_SUB`.
- Ticker extraction from plain uppercase words can produce false positives; `$TICKER` mentions are most reliable.
- yfinance data availability varies by ticker; some may be skipped if metadata/prices are missing.

## License
MIT (see LICENSE).
